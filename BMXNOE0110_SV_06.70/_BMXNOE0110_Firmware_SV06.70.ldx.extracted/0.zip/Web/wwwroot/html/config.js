
var config = 
{ 
  logo:         "../images/SchneiderElectric.gif",
  logoPocketPC: "../images/SchneiderElectricPocketPC.gif",
  titleHtml:    "FactoryCast Web Server BMX NOE 0110",
  title:        "FactoryCast&trade; BMX NOE 0110",
  titleColor:   "White",
  titleBgColor: "#138F34",
  homeImage:     "../../images/Mirano.jpg",
  homeVersion:   "Web site version : 6.40",
  homeCopyRight: "&copy; 2017 Schneider Electric. All Rights Reserved."
}

