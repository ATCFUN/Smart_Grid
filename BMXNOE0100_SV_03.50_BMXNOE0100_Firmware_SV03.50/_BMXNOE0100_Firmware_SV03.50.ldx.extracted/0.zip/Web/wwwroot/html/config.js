var config = {
    logo: "../images/SchneiderElectric.gif",
    logoPocketPC: "../images/SchneiderElectricPocketPC.gif",
    titleHtml: "BMX NOE 0100 B",
    title: "BMX NOE 0100 B",
    titleColor: "White",
    titleBgColor: "#138F34",
    homeImage: "../../images/Mirano.jpg",
    homeVersion: "Web site version : 4.60",
    homeCopyRight: "&copy; 2017 Schneider Electric. All Rights Reserved."
}