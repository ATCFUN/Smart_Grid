/* $Id: cbuslib.js $ */
/*!
 * \file
 *
 * \copyright
 * Copyright (c) 2016, Schneider Electric (Australia) Pty Ltd.
 * All rights reserved.
 * --------------------------------------------------------------------------
 *
 * \brief
 * Javasript CBus library for encoding/decoding Cbus object information.
 *
 * \details
 *
 *
 * \author Andrew Chalmers
 * \date Wed 30 Mar 14:47:16 ACDT 2016
 *
 * @attention
 * @par ASSUMPTIONS:
 * None.
 * @par MODIFICATION HISTORY:
 * @table RevisionTable
 * || Date   | Author | Change Description ||
 * --
 * || 30-Mar-16 | AC  | Initial javascript CBus Library. ||
 * @endtable
 *
 *****************************************************************************/

var Cbuslib = {};
Cbuslib.debug = function () { console.log.apply(null, arguments); };
// Comment this line to get debug output
Cbuslib.debug = function () {};

Cbuslib.appType = function(){
  //if SHAC remove support for EMERGENCY_LIGHT
  if(typeof Config !== 'undefined' && Config.brand.indexOf('SHAC') > -1){
      return {
        'LIGHTING_LOW':       0x30,
        'LIGHTING_HIGH':      0x7F,

        //'EMERGENCY_LIGHT':    0xEE,
        'TEMP_BC':            0x19,
        'LIGHTING':           0x38,
        'HEATING':            0x88,
        'AIR_CONDITIONING':   0xAC,
        'INFO_MESSAGES':      0xAD,
        'MEDIA_TRANSPORT':    0xC0,
        'TRIGGER':            0xCA,
        'ENABLE':             0xCB,
        'AUDIO':              0xCD,
        'ERROR':              0xCE,
        'SECURITY':           0xD0,
        'TIME':               0xDF,
        'TELEPHONY':          0xE0,
        'MEASUREMENT':        0xE4,
        'USER_PARAM':         0xFA,
        'NETWORK_CONTROL':    0xFF // Used for unit parameters
      }
  }else{
      return {
        'LIGHTING_LOW':       0x30,
        'LIGHTING_HIGH':      0x7F,

        'EMERGENCY_LIGHT':    0xEE,
        'TEMP_BC':            0x19,
        'LIGHTING':           0x38,
        'HEATING':            0x88,
        'AIR_CONDITIONING':   0xAC,
        'INFO_MESSAGES':      0xAD,
        'MEDIA_TRANSPORT':    0xC0,
        'TRIGGER':            0xCA,
        'ENABLE':             0xCB,
        'AUDIO':              0xCD,
        'ERROR':              0xCE,
        'SECURITY':           0xD0,
        'TIME':               0xDF,
        'TELEPHONY':          0xE0,
        'MEASUREMENT':        0xE4,
        'USER_PARAM':         0xFA,
        'NETWORK_CONTROL':    0xFF // Used for unit parameters
      }
  }  
}();

Cbuslib.measurementUnits = [
  "°C",
  "A",
  "°",
  "C",
  "bool",
  "F",
  "H",
  "Hz",
  "J",
  "K",
  "Kg/m³",
  "Kg",
  "L",
  "L/hr",
  "L/min",
  "L/sec",
  "lx",
  "m",
  "m/min",
  "m/sec",
  "m/sec²",
  "mol",
  "Nm",
  "N",
  "Ω",
  "Pa",
  "%",
  "dB",
  "PPM",
  "RPM",
  "sec",
  "min",
  "hr",
  "Sv",
  "sr",
  "T",
  "V",
  "W/hr",
  "W",
  "Wb",
  "$",
  "$/hr"
];

Cbuslib.measurementUnitNames = [
  "°C",
  "A",
  "deg",
  "Coulomb",
  "bool",
  "F",
  "H",
  "Hz",
  "J",
  "Katal",
  "Kg/m³",
  "Kg",
  "L",
  "L/hr",
  "L/min",
  "L/sec",
  "lux",
  "m",
  "m/min",
  "m/sec",
  "m/sec²",
  "mole",
  "Nm",
  "N",
  "Ohm",
  "Pa",
  "%",
  "dB",
  "PPM",
  "RPM",
  "sec",
  "min",
  "hr",
  "Sievert",
  "Steradian",
  "T",
  "V",
  "W/hr",
  "W",
  "Weber",
  "$",
  "$/hr"
];

Cbuslib.errorsyscat = {
  // Input units (class 0b0101)
  'Key unit' :				0x140,
  'Telecommand and Remote Entry' :	0x144,
  'Temperature Sensor' :		0x148,

  // Support units (class 0b1001)
  'PSU' :	 			0x240,

  // Building Management Systems (class 0b1011)
  'BMS Reporting' :			0x2c0,

  // Output units (class 0b1101)
  'LE Dimmer' :				0x340,
  'TE Dimmer' :				0x344,
  'Relay' :				0x350,
  'PWM/LED Dimmer' :			0x358,
  'Sinewave Dimmer' :			0x35c,
  'DALI/DSI' :				0x368,
  'Modular Dimmer' :			0x36c,
  'Universal Dimmer' :			0x374,
  'Device Controller' :			0x378,

  // Climate controllers (0b1111)
  'A/C System' :			0x3c0,
};

// Which system IDs support channels
Cbuslib.error_channel_sysids = [
  0x148,
  0x340,
  0x344,
  0x350,
  0x358,
  0x35c,
  0x368,
  0x36c,
  0x374,
];

Cbuslib.error_severity = {
    0 : 'All OK',
    1 : 'OK',
    2 : 'Minor failure',
    3 : 'General failure',
    4 : 'Extreme failure',
};

Cbuslib.error_dig_temp_errs = {
    0 :	'OK',
    1 :	'No sensor',
    2 : 'Short circuit',
    3 :	'Reserved',
};

Cbuslib.error_dimmer_errs = {
    0 : 'OK',
    1 : 'No power',
    2 : 'Over temperature',
    3 : 'Over current',
    4 : 'Control communication error',
    5 : 'Status communication error',
    6 : 'Reserved',
    7 : 'No hardware',
};

Cbuslib.error_relay_errs = {
    0 : 'OK',
    1 : 'No power',
    2 : 'Over temperature',
    3 : 'Over current',
    7 : 'Load failure',
};

Cbuslib.error_modular_errs = {
    0 : 'OK',
    1 : 'No power',
    2 : 'Over temperature',
    3 : 'Over current',
    4 : 'Control communication error',
    5 : 'Status communication error',
    6 : 'Ballast controller failure',
    7 : 'No hardware',
};

/*
 * MRA Consts
 */
Cbuslib.CBUS_AUDIO_M_FEED_ID_MAX = 7;
Cbuslib.MAX_MRA_MTC_COMMAND_OBJ_SIZE = 50;
Cbuslib.MAX_MRA_MTC_STR_OBJ_SIZE = 256;
/*
 * MRA FUNCTION ADDR
 */
Cbuslib.MRAFuncAddr = {
  MRA_FUNC_ADDR_VOLUME : 0,
  MRA_FUNC_ADDR_BALANCE : 1,
  MRA_FUNC_ADDR_BASS : 2,
  MRA_FUNC_ADDR_TREBLE : 3,
  MRA_FUNC_ADDR_MUTE : 4,
  MRA_FUNC_ADDR_SRC_NUM : 5,
  MRA_FUNC_ADDR_D1_LABEL : 6,
  MRA_FUNC_ADDR_D2_LABEL : 7,
  MRA_FUNC_ADDR_SRC_DESC : 8,
  MRA_FUNC_ADDR_ZONE_DESC : 9,
  MRA_FUNC_ADDR_MRA_COMMAND : 10,
  MRA_FUNC_ADDR_NUM : 11,
};

Cbuslib.MRAFuncNames = [
    'Volume',
    'Balance',
    'Bass',
    'Treble',
    'Mute',
    'Source Number',
    'Dynamic1 LABEL',
    'Dynamic2 LABEL',
    'Source Descriptor',
    'Zone Descriptor',
    'MRA Command',
];

Cbuslib.mra_function = {
    0 : 'Volume',
    1 : 'Balance',
    2 : 'Bass',
    3 : 'Treble',
    4 : 'Mute',
    5 : 'Source Number',
    6 : 'Dynamic1 LABEL',
    7 : 'Dynamic2 LABEL',
    8 : 'Source Descriptor',
    9 : 'Zone Descriptor',
    10 : 'MRA Command',
};

/*
 * MRA DATA TYPE
 */
Cbuslib.MRADataType = {
  MRA_DATA_TYPE_VOLUME_ALIKE : 0,
  MRA_DATA_TYPE_UINT8 : 1,
  MRA_DATA_TYPE_STRING : 2,
  MRA_DATA_TYPE_UNSUPPORTED : 3,
};

/*
 * MRA DATA TYPE MAP
 */
Cbuslib.audioDatatypeMap = [
  Cbuslib.MRADataType.MRA_DATA_TYPE_VOLUME_ALIKE, Cbuslib.MRADataType.MRA_DATA_TYPE_VOLUME_ALIKE,
  Cbuslib.MRADataType.MRA_DATA_TYPE_VOLUME_ALIKE, Cbuslib.MRADataType.MRA_DATA_TYPE_VOLUME_ALIKE,
  Cbuslib.MRADataType.MRA_DATA_TYPE_UINT8, Cbuslib.MRADataType.MRA_DATA_TYPE_UINT8,
  Cbuslib.MRADataType.MRA_DATA_TYPE_STRING, Cbuslib.MRADataType.MRA_DATA_TYPE_STRING,
  Cbuslib.MRADataType.MRA_DATA_TYPE_STRING, Cbuslib.MRADataType.MRA_DATA_TYPE_STRING,
  Cbuslib.MRADataType.MRA_DATA_TYPE_STRING
];
/**
 * MRA Commands
 */
Cbuslib.MRACommandType = {
  MRA_CMD_TYPE_NEXT_FEED : 0,
  MRA_CMD_TYPE_PREVIOUS_FEED : 1,
  MRA_CMD_ALL_OFF : 2,
  MRA_CMD_ZONE_DES_REQ : 3,
  MRA_CMD_FEED_DES_REQ : 4,
  MRA_CMD_CUR_FEED_REQ : 5,
  MRA_CMD_DYNAMIC1 : 6,
  MRA_CMD_DYNAMIC2 : 7,
  MRA_CMD_PRIORITY_ON : 8,
  MRA_CMD_PRIORITY_OFF : 9,
  MRA_CMD_SET_OFF_TIMER : 10,
  MRA_CMD_CANCEL_OFF_TIMER : 11,
  MRA_CMD_ERROR_CODE : 12,
  MRA_CMD_STATUS_REQUEST : 13,
  MRA_CMD_OFF_TIMER_EXPIRED : 14,
  MAX_MRA_COMMAND_NUM : 15,
};

Cbuslib.MRA_MTC_CMD_PARAMETER_DELIMITER = ":";
Cbuslib.mraCommands = [
  "Next Feed", "Previous Feed", "All Off", "Zone Descriptor Request",
  "Feed Descriptor Request", "Current Feed Request", "Dynamic1", "Dynamic2",
  "Priority On", "Priority Off", "Set Off Timer", "Cancel Off Timer",
  "Error Code", "Status Request", "Off Timer Expired"
];

//MRA cmd parameter length according to MRACommandType
Cbuslib.mraCmdParameterLength = [ 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1, 0, 1, 0, 0 ];

/*
 * MTC Consts
 */
Cbuslib.MAX_MTC_TRACK_NUM = 2147483647;
Cbuslib.MAX_MTC_SEL_NUM = 32767;

/*
 * MTC FUNCTION ADDR
 */
Cbuslib.MTCFuncAddr = {
  MTC_FUNC_ADDR_PLAY_STOP : 0,
  MTC_FUNC_ADDR_PAUSE_RESUME : 1,
  MTC_FUNC_ADDR_CATEGORY : 2,
  MTC_FUNC_ADDR_SELECTION : 3,
  MTC_FUNC_ADDR_TRACK : 4,
  MTC_FUNC_ADDR_SHUFFLE : 5,
  MTC_FUNC_ADDR_REPEAT : 6,
  MTC_FUNC_ADDR_FORWARD : 7,
  MTC_FUNC_ADDR_REWIND : 8,
  MTC_FUNC_ADDR_SOURCE_POWER_CONTROL : 9,
  MTC_FUNC_ADDR_TOTAL_TRACKS : 10,
  MTC_FUNC_ADDR_CURRENT_TRACK_NAME : 11,
  MTC_FUNC_ADDR_CURRENT_SELECTION_NAME : 12,
  MTC_FUNC_ADDR_CURRENT_CATEGORY_NAME : 13,
  MTC_FUNC_ADDR_NEXT_TRACK_NAME : 14,
  MTC_FUNC_ADDR_NEXT_SELECTION_NAME : 15,
  MTC_FUNC_ADDR_NEXT_CATEGORY_NAME : 16,
  MTC_FUNC_ADDR_PREVIOUS_TRACK_NAME : 17,
  MTC_FUNC_ADDR_PREVIOUS_SELECTION_NAME : 18,
  MTC_FUNC_ADDR_PREVIOUS_CATEGORY_NAME : 19,
  MTC_FUNC_ADDR_NEXT2_TRACK_NAME : 20,
  MTC_FUNC_ADDR_NEXT2_SELECTION_NAME : 21,
  MTC_FUNC_ADDR_NEXT2_CATEGORY_NAME : 22,
  MTC_FUNC_ADDR_PREVIOUS2_TRACK_NAME : 23,
  MTC_FUNC_ADDR_PREVIOUS2_SELECTION_NAME : 24,
  MTC_FUNC_ADDR_PREVIOUS2_CATEGORY_NAME : 25,
  MTC_FUNC_ADDR_MTC_COMMAND : 26,
  MTC_FUNC_ADDR_MTC_ENUM_SIZE_CAT : 27,
  MTC_FUNC_ADDR_MTC_ENUM_SIZE_SEL : 28,
  MTC_FUNC_ADDR_MTC_ENUM_SIZE_TRK : 29,
  MTC_FUNC_ADDR_MTC_ENUM_NAMES_CAT : 30,
  MTC_FUNC_ADDR_MTC_ENUM_NAMES_SEL : 31,
  MTC_FUNC_ADDR_MTC_ENUM_NAMES_TRK : 32,
  MTC_FUNC_ADDR_NUM : 33,
};

Cbuslib.MTCFuncNames = [
    'Play/Stop',
    'Pause/Resume',
    'Category',
    'Selection',
    'Track',
    'Shuffle',
    'Repeat',
    'Forward',
    'Rewind',
    'Source Power Control',
    'Total Tracks',
    'Current Track Name',
    'Current Selection Name',
    'Current Category Name',
    'Next Track Name',
    'Next Selection Name',
    'Next Category Name',
    'Previous Track Name',
    'Previous Selection Name',
    'Previous Category Name',
    'Next 2 Track Name',
    'Next 2 Selection Name',
    'Next 2 Category Name',
    'Previous 2 Track Name',
    'Previous 2 Selection Name',
    'Previous 2 Category Name',
    'MTC Command',
    'Enum Category Size',
    'Enum Selection Size',
    'Enum Track Size',
    'Enum Category Names',
    'Enum Selection Names',
    'Enum Track Names',
];

/*
 * MTC DATA TYPE
 */
Cbuslib.MTCDataType = {
  MTC_DATA_TYPE_UINT8 : 0,
  MTC_DATA_TYPE_UINT16 : 1,
  MTC_DATA_TYPE_UINT32 : 2,
  MTC_DATA_TYPE_STRING : 3,
  MTC_DATA_TYPE_UNSUPPORTED : 4,
};

/*
 * MTC DATA TYPE MAP
 */
Cbuslib.mtcDatatypeMap = [
  Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT8, Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT8, Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT8, Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT16,
  Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT32, Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT8, Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT8, Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT8,
  Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT8, Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT8, Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT32, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING,
  Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING,
  Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING,
  Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING,
  Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING, Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT8,
  Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT8, Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT8, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING, Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING,
  Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING
];

/**
 * MTC commands
 */

Cbuslib.MTCCommandType = {
  MTC_CMD_TYPE_NEXT_CATEGORY : 0,
  MTC_CMD_TYPE_PREVIOUS_CATEGORY : 1,
  MTC_CMD_TYPE_NEXT_SELECTION : 2,
  MTC_CMD_TYPE_PREVIOUS_SELECTION : 3,
  MTC_CMD_TYPE_NEXT_TRACK : 4,
  MTC_CMD_TYPE_PREVIOUS_TRACK : 5,
  MTC_CMD_TYPE_MEDIA_STATUS_REQ : 6,
  MTC_CMD_TYPE_ENUM_CATEGORIES : 7,
  MTC_CMD_TYPE_ENUM_SELECTIONS : 8,
  MTC_CMD_TYPE_ENUM_TRACKS : 9,
  MAX_MTC_COMMAND_NUM : 10,
};
Cbuslib.mtcCommands = [
  "Next Category", "Previous Category", "Next Selection", "Previous Selection",
  "Next Track", "Previous Track", "Media Status", "Enumerate Categories",
  "Enumerate Selections", "Enumerate Tracks"
];

Cbuslib.mtc_function = {
    0 : 'Play/Stop',
    1 : 'Pause/Resume',
    2 : 'Category',
    3 : 'Selection',
    4 : 'Track',
    5 : 'Shuffle',
    6 : 'Repeat',
    7 : 'Forward',
    8 : 'Rewind',
    9 : 'Source Power Control',
    10 : 'Total Tracks',
    11 : 'Current Track Name',
    12 : 'Current Selection Name',
    13 : 'Current Category Name',
    14 : 'Next Track Name',
    15 : 'Next Selection Name',
    16 : 'Next Category Name',
    17 : 'Previous Track Name',
    18 : 'Previous Selection Name',
    19 : 'Previous Category Name',
    20 : 'Next 2 Track Name',
    21 : 'Next 2 Selection Name',
    22 : 'Next 2 Category Name',
    23 : 'Previous 2 Track Name',
    24 : 'Previous 2 Selection Name',
    25 : 'Previous 2 Category Name',
    26 : 'MTC Command',
    27 : 'Enum Category Size', 
    28 : 'Enum Selection Size',
    29 : 'Enum Track Size',
    30 : 'Enum Category Names', 
    31 : 'Enum Selection Names',
    32 : 'Enum Track Names',
};

// MTC cmd parameter length according to MTCCommandType
Cbuslib.mtcCmdParameterLength = [ 0, 0, 0, 0, 0, 0, 0, 1, 1, 1 ];

Cbuslib.MAX_RAMP_RATE = 15;
//array of ramp rates used to set the ramp rate in a C-Bus command
Cbuslib.rampRates = [
  0, 4, 8, 12,
  20, 30, 40, 60,
  90, 120, 180, 300,
  420, 600, 900, 1020
];

/* Generate various lists shared with cbus_lorax_share.[ch]
 *
 * Pass the contents of SEC_OBJECT_CODES through..
 * sed -nEe 's|.*E\(([^.]+), "(.*)", DT_(.*)\).*|\1,\2,\3|p' | awk -F , 'BEGIN {i = 0} {printf("[\"%s\", \"%s\", Scada.dt.%s], // %d\n", $1, $2, tolower($3), i); i++}'
 *
 * XXX: Scada.dt.access is abused for command
 */
(function() {
  var l = [
    ["SEC_COMMAND", "Command", Scada.dt.access], // 0
    ["SEC_ALARM_SOUNDING", "Alarm sounding", Scada.dt.bool], // 1
    ["SEC_ALL_ZONES_OK", "All zones OK", Scada.dt.bool], // 2
    ["SEC_ARM_FAILED", "Arm failed", Scada.dt.bool], // 3
    ["SEC_ARM_READY", "Arm ready", Scada.dt.bool], // 4
    ["SEC_ARMED_STATE", "Armed state", Scada.dt.uint8], // 5
    ["SEC_BATTERY_CHARGING", "Battery charging", Scada.dt.bool], // 6
    ["SEC_ENTRY_DELAY", "Entry delay", Scada.dt.bool], // 7
    ["SEC_EXIT_DELAY", "Exit delay", Scada.dt.bool], // 8
    ["SEC_FIRE_ALARM", "Fire alarm", Scada.dt.bool], // 9
    ["SEC_GAS_ALARM", "Gas alarm", Scada.dt.bool], // 10
    ["SEC_LINE_CUT_ALARM", "Line cut alarm", Scada.dt.bool], // 11
    ["SEC_LOW_BATTERY", "Low battery", Scada.dt.bool], // 12
    ["SEC_MAINS_FAILURE", "Mains failure", Scada.dt.bool], // 13
    ["SEC_NORMAL_OPERATION", "Normal operation", Scada.dt.bool], // 14
    ["SEC_OTHER_ALARM", "Other alarm", Scada.dt.bool], // 15
    ["SEC_PANIC", "Panic", Scada.dt.bool], // 16
    ["SEC_PASSWORD_STATUS", "Password status", Scada.dt.uint8], // 17
    ["SEC_PASSWORD_OK", "Password OK", Scada.dt.bool], // 18
    ["SEC_TAMPER", "Tamper", Scada.dt.bool], // 19
    ["SEC_ZONE_ISOLATED", "Zone isolated", Scada.dt.bool], // 20
    ["SEC_ZONE_STATE", "Zone state", Scada.dt.uint8], // 21
    ["SEC_ZONE_NAME", "Zone name", Scada.dt.string], // 22
  ];

  Cbuslib.securityObjectNames = {};
  Cbuslib.securityObjectCode = {};
  Cbuslib.securityObjectType = [];
  var llen = l.length;
  for (var i = 0; i < llen; i++) {
    Cbuslib.securityObjectCode[l[i][0]] = i;
    Cbuslib.securityObjectNames[l[i][1]] = i;
    Cbuslib.securityObjectType.push(l[i][2]);
  }
  Cbuslib.securityObjectCode.SEC_MAX = i;
})();

/*
 * Pass the contents of SEC_COMMANDS through..
 * sed -nEe 's|.*E\(([^.]+), "(.*)").*|\1,\2|p' | awk -F , 'BEGIN {i = 0} {printf("[\"%s\", \"%s\"], // %d\n", $1, $2, i); i++}'
 */
(function() {
  var l = [
    ["SECCMD_KEYPRESS", "Keypress"], // 0
    ["SECCMD_RAISE_ALARM", "Raise alarm"], // 1
    ["SECCMD_ARM", "Arm"], // 2
    ["SECCMD_RAISE_TAMPER", "Raise tamper"], // 3
    ["SECCMD_DROP_TAMPER", "Drop tamper"], // 4
    ["SECCMD_MESSAGE", "Message"], // 5
  ];

  Cbuslib.securityCommands = {};
  Cbuslib.securityCommandNames = [];
  var llen = l.length;
  for (var i = 0; i < llen; i++) {
    Cbuslib.securityCommands[l[i][0]] = i;
    Cbuslib.securityCommandNames.push(l[i][1]);
  }
  Cbuslib.securityCommands.SECCMD_MAX = i;
})();

Cbuslib.SEC_MAX_MESSAGE_LEN = 16;

Cbuslib.securitySpecialKeys = {
  0x0d : 'Enter',
  0x80 : 'Shift',
  0x81 : 'Panic',
  0x82 : 'Fire',
  0x83 : 'Arm',
  0x84 : 'Away',
  0x85 : 'Night',
  0x86 : 'Day',
  0x87 : 'Vacation',
};

// Match with cbuslib.lua armlevels
Cbuslib.securityArmLevels = {
  0x01 : 'Away',
  0x02 : 'Night',
  0x03 : 'Day',
  0x04 : 'Vacation',
  0xff : 'Highest',
};

/* 
//only for Emergency Exit Light
*/
Cbuslib.linetype = function(id) {
    var linetype = ((id >>> 8) & 0xFF).toString(2);
    linetype = "00000000".substr(linetype.length) + linetype;      
    return parseInt(linetype.substring(1, 2), 2); //changed for ind obj
};
Cbuslib.objecttype = function(id) {
    var objecttype = ((id >>> 8) & 0xFF).toString(2);
    objecttype = "00000000".substr(objecttype.length) + objecttype;      
    return parseInt(objecttype.substring(0, 1), 2);
};
Cbuslib.tagidtoemergencyids = function(id, type) {
    var tagid, grpId, unitid, line;
    tagid = parseInt(id);
    if(tagid >= 32768){
        grpId = (tagid - 32768)
    }else{
        unitid = Math.floor(tagid/128);
        line = Math.floor((tagid%128)/64);
        grpId = (tagid%128)%64;
    } 
    if(type == 'unitid'){
      return unitid;
    }else if(type == 'line'){
      return line;
    }else if(type == 'groupid'){
      return grpId;
    }
};

Cbuslib.UNIT_PARAM_MIN = 1;
Cbuslib.UNIT_PARAM_MAX = 4;

/*!
 * \brief Converts binary-encoded CBus global Unit address to Lua string.
 * Network and unit fields separated by '.'.
 *
 * \param address  The 16-bit binary value for the unit address.
 * \return The corresponding Network wide Unit address string.
 *         This consists of the network address and unit address
 *         separated by a '.'.
 *
 *****************************************************************************/
Cbuslib.decodeUnitAddress = function(address)
{
  var unit = parseInt(address);

  return isNaN(unit) ? 'error' : [(unit >> 8) & 0xFF, unit & 0xFF].join('.');
};

/*!
 * \brief Converts string to binary-encoded CBus global Unit address.
 * Returns unit address a single javascript number.
 * Network and unit fields must be separated by '.'.
 *
 * \param address  Network wide Unit address. This consists of a network
 *                 address and unit address separated by a '.'
 * \return The 16-bit binary number for the unit address.
 *
 *****************************************************************************/
Cbuslib.encodeUnitAddress = function(address)
{
  var i, network, unit, res = false;

  i = address.split('.');
  if (i.length == 2)
  {
    network = parseInt(i[0]);
    unit = parseInt(i[1]);

    if (!isNaN(network) && !isNaN(unit) )
    {
      res = ((network & 0x0FF) << 8) | (unit & 0x0FF);
    }
  }
  return res;
}


/*!
 * \brief Converts binary-encoded object address to Lua string.
 * Subfields separated by '/'.
 *
 * \param address  The 32-bit binary object address.
 * \return The string format version of the object address.
 *         This consists an application address and address subfields
 *         separated by a '/'.
 *
 *****************************************************************************/
Cbuslib.decodeObjectAddress = function(address)
{
  var objectAddress =  parseInt(address);

  if (isNaN(objectAddress))
    return false;
  var application = (objectAddress >> 24) & 0xff;
  var network = (objectAddress >> 16) & 0xff;
  var p1 = (objectAddress >> 8) & 0xff;
  var p2 = objectAddress & 0xff;
  var name = [];

  switch (application)
  {
    case Cbuslib.appType.MEASUREMENT:
    case Cbuslib.appType.AUDIO:
    case Cbuslib.appType.SECURITY:
    case Cbuslib.appType.MEDIA_TRANSPORT:
    // Used for unit parameters
    case Cbuslib.appType.NETWORK_CONTROL:
      if (application == Cbuslib.appType.NETWORK_CONTROL && (p2 < Cbuslib.UNIT_PARAM_MIN || p2 > Cbuslib.UNIT_PARAM_MAX)) {
        return false;
      }
      if (application == Cbuslib.appType.SECURITY && ((p1 < Cbuslib.securityObjectCode.SEC_ZONE_ISOLATED && p2 > 0) || (p1 >= Cbuslib.securityObjectCode.SEC_MAX)))
        return false;
      name = [network, application, p1, p2];
    break;

    case Cbuslib.appType.USER_PARAM:
    name = [network, application, p1 << 8 | p2];
    break;

    case Cbuslib.appType.ERROR:
      var err_devid = (objectAddress >> 8) & 0xff;
      var err_channel = (objectAddress >> 0) & 0xff;
      if(err_devid == 255){
        name = [network, application, err_devid];
      }else{
        name = [network, application, err_devid, err_channel];
      }     
    break;

    case Cbuslib.appType.EMERGENCY_LIGHT:
      var grp = (p1).toString(2);
      grp = "00000000".substr(grp.length) + grp;
      var objecttype = parseInt(grp.substring(0, 1), 2);
      if(objecttype === 0){
        name = [network, application, p2, parseInt(grp.substring(1, 2), 2), parseInt(grp.substring(2, 8), 2) ];
      }else{
        name = [network, application, parseInt(grp.substring(2, 8), 2) ];
      }      
      break;

    default:
      name = [network, application, p1];
      break;
  }

  return name.join('/');
};


/*!
 * \brief Converts a string to binary-encoded CBus object address.
 * Returns object address a single 32-bit number.
 * Address subfields must be separated by '/'.
 *
 * \param address  Cbus object address. This consists of an application
 *                 address and address subfields separated by a '/'
 *                 The subfields are application dependent.
 * \return The 32-bit binary object address.
 *
 *****************************************************************************/
Cbuslib.encodeObjectAddress = function(address)
{
  var g = address.split('/');
  var res = false;
  var vals = [];

  if (g.length < 3 || g.length > 5) {
    Cbuslib.debug("Incorrect number of elements for address");
    return false;
  }

  for (i = 0; i < g.length; i++) { // Parse & validate
    vals[i] = parseInt(g[i]);
    if (isNaN(vals[i])) {
      Cbuslib.debug("Unparseable value for address");
      return false;
    }
    // Only first 2 as user param can be bigger
    if (i < 2 && (vals[i] < 0 || vals[i] > 255)) {
      Cbuslib.debug("Out of range value for network or application");
      return false;
    }
  }

  if (vals[1] == Cbuslib.appType.USER_PARAM) {
    if (vals[2] < 0 || vals[2] > 65535) {
      Cbuslib.debug("Unparseable / out of range value for address");
      return false;
    }
  }

  if (vals[1] == Cbuslib.appType.ERROR) {
    if (vals[2] < 0 || vals[2] > 255) {
      Cbuslib.debug("Unparseable / out of range value for address");
      return false;
    }
  }

  if (vals[1] == Cbuslib.appType.EMERGENCY_LIGHT) {
    if(g.length === 5){ //individual object
        if (vals[2] < 0 || vals[2] > 255) {
          Cbuslib.debug("Unparseable / out of range value for address");
          return false;
        }
        if (vals[3] < 0 || vals[3] > 1) {
          Cbuslib.debug("Unparseable / out of range value for address");
          return false;
        }
        if (vals[4] < 0 || vals[4] > 63) {
          Cbuslib.debug("Unparseable / out of range value for address");
          return false;
        }
    }else if(g.length === 3){ //group object
        if (vals[2] < 0 || vals[2] > 63) {
          Cbuslib.debug("Unparseable / out of range value for address");
          return false;
        }
    }else{
        Cbuslib.debug("Incorrect number of elements for measurement address");
        return false;
    }    
  }

  res = vals[1] << 24 | vals[0] << 16;
  switch(vals[1])
  {
    case Cbuslib.appType.EMERGENCY_LIGHT:
      if (g.length === 5) {
          var shortAdd = vals[4].toString(2);  //SA
          shortAdd = "000000".substr(shortAdd.length) + shortAdd;
          var lineType = vals[3].toString(2);  //Line
          var objectType = "0"; //0 -> individual object
          var grAdd = objectType + lineType + shortAdd; //group Addr for EL - 8 bit string

          res |= parseInt(grAdd, 2) << 8 | vals[2];
      }else if(g.length === 3){
          res |= vals[2] << 8;
      }    
    break;

    case Cbuslib.appType.MEASUREMENT:
    case Cbuslib.appType.AUDIO:
    case Cbuslib.appType.MEDIA_TRANSPORT:
    if (g.length != 4) {
      Cbuslib.debug("Incorrect number of elements for measurement address");
      return false;
    }
    res |= vals[2] << 8 | vals[3];
    break;

    case Cbuslib.appType.USER_PARAM:
    if (g.length != 3) {
      Cbuslib.debug("Incorrect number of elements");
      return false;
    }
    res |= vals[2];
    break;
 
    case Cbuslib.appType.ERROR:
    if (g.length === 4) {
      res |= vals[2] << 8 | vals[3];
    }else if(g.length === 3){
      res |= vals[2] << 8 | 255;
    }
    break;    

    // Used for unit parameters
    case Cbuslib.appType.NETWORK_CONTROL:
    if (g.length != 4) {
      Cbuslib.debug("Incorrect number of elements for unit parameter");
      return false;
    }

    if (vals[3] < Cbuslib.UNIT_PARAM_MIN || vals[3] > Cbuslib.UNIT_PARAM_MAX) {
      Cbuslib.debug("Unit parameter out of range");
      return false;
    }

    res |= vals[2] << 8 | vals[3];
    break;

    case Cbuslib.appType.SECURITY:
    if (g.length != 4) {
      Cbuslib.debug("Incorrect number of elements for security address");
      return false;
    }
    if (vals[2] < Cbuslib.securityObjectCode.SEC_ZONE_ISOLATED && vals[3] > 0)
      return false;
    if (vals[2] >= Cbuslib.securityObjectCode.SEC_MAX)
      return false;
    res |= vals[2] << 8 | vals[3];
    break;

    default:
    if (!Cbuslib.appTypeIsLightingLike(vals[1])) {
      Cbuslib.debug("Unsupported application");
      return false;
    }
    if (g.length != 3) {
      Cbuslib.debug("Incorrect number of elements for lighting address");
      return false;
    }
    res |= vals[2] << 8;
    break;
  }

  return res >>> 0; // Convert to unsigned
}

// Parse hex string into [binary] string
Cbuslib.hex2bin = function (s)
{
  var r = "";
  for (var i = 0, l = s.length; i < l; r += String.fromCharCode(parseInt(s.substr(i, 2), 16)), i += 2)
    ;

  return r;
}

//+ Jonas Raoni Soares Silva
//@ http://jsfromhell.com/classes/binary-parser [rev. #1]
Cbuslib.BinaryParser = function(bigEndian, allowExceptions){
    this.bigEndian = bigEndian, this.allowExceptions = allowExceptions;
};
with({p: Cbuslib.BinaryParser.prototype}){
    p.encodeFloat = function(number, precisionBits, exponentBits){
        var bias = Math.pow(2, exponentBits - 1) - 1, minExp = -bias + 1, maxExp = bias, minUnnormExp = minExp - precisionBits,
        status = isNaN(n = parseFloat(number)) || n == -Infinity || n == +Infinity ? n : 0,
        exp = 0, len = 2 * bias + 1 + precisionBits + 3, bin = new Array(len),
        signal = (n = status !== 0 ? 0 : n) < 0, n = Math.abs(n), intPart = Math.floor(n), floatPart = n - intPart,
        i, lastBit, rounded, j, result;
        for(i = len; i; bin[--i] = 0);
        for(i = bias + 2; intPart && i; bin[--i] = intPart % 2, intPart = Math.floor(intPart / 2));
        for(i = bias + 1; floatPart > 0 && i; (bin[++i] = ((floatPart *= 2) >= 1) - 0) && --floatPart);
        for(i = -1; ++i < len && !bin[i];);
        if(bin[(lastBit = precisionBits - 1 + (i = (exp = bias + 1 - i) >= minExp && exp <= maxExp ? i + 1 : bias + 1 - (exp = minExp - 1))) + 1]){
            if(!(rounded = bin[lastBit]))
                for(j = lastBit + 2; !rounded && j < len; rounded = bin[j++]);
            for(j = lastBit + 1; rounded && --j >= 0; (bin[j] = !bin[j] - 0) && (rounded = 0));
        }
        for(i = i - 2 < 0 ? -1 : i - 3; ++i < len && !bin[i];);

        (exp = bias + 1 - i) >= minExp && exp <= maxExp ? ++i : exp < minExp &&
            (exp != bias + 1 - len && exp < minUnnormExp && this.warn("encodeFloat::float underflow"), i = bias + 1 - (exp = minExp - 1));
        (intPart || status !== 0) && (this.warn(intPart ? "encodeFloat::float overflow" : "encodeFloat::" + status),
            exp = maxExp + 1, i = bias + 2, status == -Infinity ? signal = 1 : isNaN(status) && (bin[i] = 1));
        for(n = Math.abs(exp + bias), j = exponentBits + 1, result = ""; --j; result = (n % 2) + result, n = n >>= 1);
        for(n = 0, j = 0, i = (result = (signal ? "1" : "0") + result + bin.slice(i, i + precisionBits).join("")).length, r = [];
            i; n += (1 << j) * result.charAt(--i), j == 7 && (r[r.length] = String.fromCharCode(n), n = 0), j = (j + 1) % 8);
        r[r.length] = n ? String.fromCharCode(n) : "";
        return (this.bigEndian ? r.reverse() : r).join("");
    };
    p.encodeInt = function(number, bits, signed){
        var max = Math.pow(2, bits), r = [];
        (number >= max || number < -(max >> 1)) && this.warn("encodeInt::overflow") && (number = 0);
        number < 0 && (number += max);
        for(; number; r[r.length] = String.fromCharCode(number % 256), number = Math.floor(number / 256));
        for(bits = -(-bits >> 3) - r.length; bits--; r[r.length] = "\0");
        return (this.bigEndian ? r.reverse() : r).join("");
    };
    p.decodeFloat = function(data, precisionBits, exponentBits){
        var b = ((b = new this.Buffer(this.bigEndian, data)).checkBuffer(precisionBits + exponentBits + 1), b),
            bias = Math.pow(2, exponentBits - 1) - 1, signal = b.readBits(precisionBits + exponentBits, 1),
            exponent = b.readBits(precisionBits, exponentBits), significand = 0,
            divisor = 2, curByte = b.buffer.length + (-precisionBits >> 3) - 1,
            byteValue, startBit, mask;
        do
            for(byteValue = b.buffer[ ++curByte ], startBit = precisionBits % 8 || 8, mask = 1 << startBit;
                mask >>= 1; (byteValue & mask) && (significand += 1 / divisor), divisor *= 2);
        while(precisionBits -= startBit);
        return exponent == (bias << 1) + 1 ? significand ? NaN : signal ? -Infinity : +Infinity
            : (1 + signal * -2) * (exponent || significand ? !exponent ? Math.pow(2, -bias + 1) * significand
            : Math.pow(2, exponent - bias) * (1 + significand) : 0);
    };
    p.decodeInt = function(data, bits, signed){
        var b = new this.Buffer(this.bigEndian, data), x = b.readBits(0, bits), max = Math.pow(2, bits);
        return signed && x >= max / 2 ? x - max : x;
    };
    with({p: (p.Buffer = function(bigEndian, buffer){
        this.bigEndian = bigEndian || 0, this.buffer = [], this.setBuffer(buffer);
    }).prototype}){
        p.readBits = function(start, length){
            //shl fix: Henri Torgemane ~1996 (compressed by Jonas Raoni)
            function shl(a, b){
                for(++b; --b; a = ((a %= 0x7fffffff + 1) & 0x40000000) == 0x40000000 ? a * 2 : (a - 0x40000000) * 2 + 0x7fffffff + 1);
                return a;
            }
            if(start < 0 || length <= 0)
                return 0;
            this.checkBuffer(start + length);
            for(var offsetLeft, offsetRight = start % 8, curByte = this.buffer.length - (start >> 3) - 1,
                lastByte = this.buffer.length + (-(start + length) >> 3), diff = curByte - lastByte,
                sum = ((this.buffer[ curByte ] >> offsetRight) & ((1 << (diff ? 8 - offsetRight : length)) - 1))
                + (diff && (offsetLeft = (start + length) % 8) ? (this.buffer[ lastByte++ ] & ((1 << offsetLeft) - 1))
                << (diff-- << 3) - offsetRight : 0); diff; sum += shl(this.buffer[ lastByte++ ], (diff-- << 3) - offsetRight)
            );
            return sum;
        };
        p.setBuffer = function(data){
            if(data){
                for(var l, i = l = data.length, b = this.buffer = new Array(l); i; b[l - i] = data.charCodeAt(--i));
                this.bigEndian && b.reverse();
            }
        };
        p.hasNeededBits = function(neededBits){
            return this.buffer.length >= -(-neededBits >> 3);
        };
        p.checkBuffer = function(neededBits){
            if(!this.hasNeededBits(neededBits))
                throw new Error("checkBuffer::missing bytes");
        };
    }
    p.warn = function(msg){
        if(this.allowExceptions)
            throw new Error(msg);
        return 1;
    };
    p.toSmall = function(data){return this.decodeInt(data, 8, true);};
    p.fromSmall = function(number){return this.encodeInt(number, 8, true);};
    p.toByte = function(data){return this.decodeInt(data, 8, false);};
    p.fromByte = function(number){return this.encodeInt(number, 8, false);};
    p.toShort = function(data){return this.decodeInt(data, 16, true);};
    p.fromShort = function(number){return this.encodeInt(number, 16, true);};
    p.toWord = function(data){return this.decodeInt(data, 16, false);};
    p.fromWord = function(number){return this.encodeInt(number, 16, false);};
    p.toInt = function(data){return this.decodeInt(data, 32, true);};
    p.fromInt = function(number){return this.encodeInt(number, 32, true);};
    p.toDWord = function(data){return this.decodeInt(data, 32, false);};
    p.fromDWord = function(number){return this.encodeInt(number, 32, false);};
    p.toFloat = function(data){return this.decodeFloat(data, 23, 8);};
    p.fromFloat = function(number){return this.encodeFloat(number, 23, 8);};
    p.toDouble = function(data){return this.decodeFloat(data, 52, 11);};
    p.fromDouble = function(number){return this.encodeFloat(number, 52, 11);};
}

//Converts 8-bit binary string to object with status value
/*Cbuslib.getTestStatus = function (bin) {
  var obj = {};
  obj.testStatus = parseInt(bin.substring(0,2), 2); //fisrt 2 bits. returns Int
  obj.ballastStatus = bin.substring(2,3); // bit-3. returns string
  obj.batteryStatus = bin.substring(3,4); // bit-4
  obj.lampStatus = bin.substring(4,5); // bit-5
  obj.invertorStatus = bin.substring(5,6); // bit-6

  return obj;
}*/

// Convert hex to values for a given application
Cbuslib.getData = function(id, data) {
  var app = id >>> 24;
  if (typeof data.decodedvalue != 'undefined') {
    return data.decodedvalue;
  }

  var hex = data.datahex;
  var hexlen = hex.length;
  var flparse;

  switch (app) {
    case Cbuslib.appType.ENABLE:
      if (hexlen != 2)
	return undefined;
      return { value: parseInt(hex, 16) };

    case Cbuslib.appType.EMERGENCY_LIGHT:
      if (hexlen != 6)
          return undefined;
      return {
          mode: parseInt(hex.substring(0, 2), 16),
          //status: Cbuslib.getTestStatus(("00000000" + (parseInt(hex.substring(2, 4), 16)).toString(2)).substr(-8)),
          status: parseInt(hex.substring(2, 4), 16),
          progress: parseInt(hex.substring(4, 6), 16)       
      };

    case Cbuslib.appType.TRIGGER:
      if (hexlen != 4)
	return undefined;
      var v = parseInt(hex, 16);

      if (v == 65535)
	v = -1;
      if (v < -1 || v > 255)
	return undefined;

      return {value: v};

    case Cbuslib.appType.AUDIO:
      var funcAddr = id & 0xFF;
      if (funcAddr >= Cbuslib.audioDatatypeMap.length) {
        Cbuslib.debug('index out of range for audioDatatypeMap');
        return undefined;
      }
      var dataType = Cbuslib.audioDatatypeMap[funcAddr];
      if (dataType == Cbuslib.MRADataType.MRA_DATA_TYPE_UINT8) {
        if (hexlen != 2)
          return undefined;
        var v = parseInt(hex, 16);

        if (((funcAddr == Cbuslib.MRAFuncAddr.MRA_FUNC_ADDR_MUTE) && (v != 0) && (v != 2) && (v != 5) && (v != 7) && (v != 255))
            || ((funcAddr == Cbuslib.MRAFuncAddr.MRA_FUNC_ADDR_SRC_NUM) && ((v < 0) || (v > Cbuslib.CBUS_AUDIO_M_FEED_ID_MAX)))) {
          Cbuslib.debug('getData: invalid audio value.');
          return undefined;
        }

        return {
          value : v
        };
      } else if (dataType == Cbuslib.MRADataType.MRA_DATA_TYPE_VOLUME_ALIKE) {
        if (hexlen != 8)
          return undefined;

        // 4 bytes
        // 1: current value
        // 2: target value
        // 3-4: ramp rate (seconds for full scale ramp)
        return {
          value : parseInt(hex.substring(0, 2), 16),
          target : parseInt(hex.substring(2, 4), 16),
          ramprate : parseInt(hex.substring(4, 9), 16)
        }
      } else if (dataType == Cbuslib.MRADataType.MRA_DATA_TYPE_STRING) {
        var v = Cbuslib.hex2bin(hex);
        return {
          value : v
        };
      } else {
        return undefined;
    }
    case Cbuslib.appType.MEDIA_TRANSPORT:
      var funcAddr = id & 0xFF;
      if (funcAddr >= Cbuslib.mtcDatatypeMap.length) {
        Cbuslib.debug('index out of range for mtcDatatypeMap');
        return undefined;
      }
      var dataType = Cbuslib.mtcDatatypeMap[funcAddr];
      if (dataType == Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT8) {
        if (hexlen != 2)
          return undefined;
        var v = parseInt(hex, 16);

        if (((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_PLAY_STOP) && (v != 0) && (v != 1))
          || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_PAUSE_RESUME) && (v != 0) && (v != 255))
          || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_SHUFFLE) && (v != 0) && (v != 255))
          || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_CATEGORY) && ((v < 0) || (v > 127)))
          || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_REPEAT) && ((v < 0) || (v > 255)))
          || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_MTC_ENUM_SIZE_CAT) && ((v < 0) || (v > 255)))
          || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_MTC_ENUM_SIZE_SEL) && ((v < 0) || (v > 255)))
          || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_MTC_ENUM_SIZE_TRK) && ((v < 0) || (v > 255)))
          || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_FORWARD) && (v != 0) && (v != 2) && (v != 4) && (v != 6)
          && (v != 8) && (v != 10) && (v != 12))
          || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_REWIND) && (v != 0) && (v != 2) && (v != 4) && (v != 6)
          && (v != 8) && (v != 10) && (v != 12))
          || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_SOURCE_POWER_CONTROL) && ((v < 0) || (v > 255)))) {
          Cbuslib.debug('getData: invalid mtc value.');
          return undefined;
        }
        return {
          value : v
        };
      } else if (dataType == Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT16) {
        if (hexlen != 4)
          return undefined;
        var v = parseInt(hex, 16);

        if ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_SELECTION) && ((v < 0) || (v > Cbuslib.MAX_MTC_SEL_NUM))) {
          Cbuslib.debug('getData: invalid mtc value.');
          return undefined;
        }
        return {
          value : v
        };
      } else if (dataType == Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT32) {
        if (hexlen != 8)
          return undefined;
        var v = parseInt(hex, 16);

        if (((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_TRACK) && ((v < 0) || (v > Cbuslib.MAX_MTC_TRACK_NUM)))
          || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_TOTAL_TRACKS) && ((v < 0) || (v > Cbuslib.MAX_MTC_TRACK_NUM)))
        ) {
          Cbuslib.debug('getData: invalid mtc value.');
          return undefined;
        }
        return {
          value : v
        };
      } else if (dataType == Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING) {
        var v = Cbuslib.hex2bin(hex);
        return {
          value : v
        };
      } else {
        return undefined;
      }
    case Cbuslib.appType.USER_PARAM:
      return {};

    case Cbuslib.appType.NETWORK_CONTROL:
    case Cbuslib.appType.MEASUREMENT:
      if (hexlen != 10)
	return undefined;

      var flparse = new Cbuslib.BinaryParser(true, true);
      var val = flparse.toFloat(Cbuslib.hex2bin(hex.substring(0, 8)));
      var units = parseInt(hex.substring(8, 10), 16);
      return {
	value: val,
	units: units,
      }

    case Cbuslib.appType.ERROR:
	if (hexlen != 16) {
	    return undefined;
	}
	if (parseInt(hex.substring(0, 2)) != 0) {
	    return undefined;
	}
	var val = {};
	val.sysid = parseInt(hex.substring(2, 6), 16);
	val.sysidstr = undefined;
	for (var id in Cbuslib.errorsyscat) {
    if (Cbuslib.errorsyscat[id] == val.sysid) {
	    val.sysidstr = id;
	    break;
    }
	}
	if (val.sysidstr == undefined) {
	    return undefined;
	}
	/*var data1 = parseInt(hex.substring(6, 8), 16);
	var data2 = parseInt(hex.substring(8, 10), 16);
	val.data1 = data1;
	val.data2 = data2;*/
  var ms_err = parseInt(hex.substring(6, 8), 16);
  var mr_err = parseInt(hex.substring(8, 10), 16);
  val.ms_err = ms_err;
  val.mr_err = mr_err;

	/*val.severity = parseInt(hex.substring(10, 12), 16);
	val.ackd = Boolean(parseInt(hex.substring(12, 14), 16));
	val.devid = parseInt(hex.substring(14, 16), 16);*/
  val.ms_sev = parseInt(hex.substring(10, 12), 16);
  val.mr_sev = parseInt(hex.substring(12, 14), 16);
  var ack_flag = parseInt(hex.substring(14, 16), 16);
  val.ms_ack = false;
  val.mr_ack = false;
  
  if(ack_flag == 0 || ack_flag == 4){
    val.ms_ack = false;
    val.mr_ack = false;
  }else if(ack_flag == 1 || ack_flag == 5){
    val.mr_ack = true;
  }else if(ack_flag == 2 || ack_flag == 6){
    val.ms_ack = true;
  }else if(ack_flag == 3 || ack_flag == 7){
    val.ms_ack = true;
    val.mr_ack = true;
  }
	switch (val.sysid) {
	  case Cbuslib.errorsyscat['Temperature Sensor']:
	      //val.channel = data1;
	      val.ms_error = Cbuslib.error_dig_temp_errs[ms_err];
        val.mr_error = Cbuslib.error_dig_temp_errs[mr_err];
	      if (typeof val.ms_error === 'undefined')
		      val.ms_error = 'Unknown';
        if (typeof val.mr_error === 'undefined')
          val.mr_error = 'Unknown';
	      break;

	  case Cbuslib.errorsyscat['LE Dimmer']:
	  case Cbuslib.errorsyscat['TE Dimmer']:
	  case Cbuslib.errorsyscat['Universal Dimmer']:
	      //val.channel = data1;
	      val.ms_error = Cbuslib.error_dimmer_errs[ms_err];
        val.mr_error = Cbuslib.error_dimmer_errs[mr_err];
	      if (typeof val.ms_error === 'undefined')
          val.ms_error = 'Unknown';
        if (typeof val.mr_error === 'undefined')
          val.mr_error = 'Unknown';
	      break;

	  case Cbuslib.errorsyscat['Relay']:
	      //val.channel = data1;
	      val.ms_error = Cbuslib.error_relay_errs[ms_err];
        val.mr_error = Cbuslib.error_relay_errs[mr_err];
	      if (typeof val.ms_error === 'undefined')
          val.ms_error = 'Unknown';
        if (typeof val.mr_error === 'undefined')
          val.mr_error = 'Unknown';
	      break;

	  case Cbuslib.errorsyscat['PWM/LED Dimmer']:
	  case Cbuslib.errorsyscat['Sinewave Dimmer']:
	      //val.channel = data1;
	      break;

	  case Cbuslib.errorsyscat['DALI/DSI']:
	      //val.channel = data1 & 0x3f;
	      //val.network = data1 < 0x40 ? 'A' : 'B';
	      val.ms_error = '';
	      if (ms_err & 0x01)
		      val.ms_error += 'Ballast failure, ';
	      if (ms_err & 0x02)
		      val.ms_error += 'Lamp failure, ';
	      if (ms_err & 0x04)
		      val.ms_error += 'Lamp on, ';
	      else
		      val.ms_error += 'Lamp off, ';
	      if (ms_err & 0x08)
		      val.ms_error += 'Power failure, ';
		    if (ms_err & 0x10)
		      val.ms_error += 'Emergency light failure, ';
	      if (ms_err & 0x80)
		      val.ms_error += 'Ballast missing, ';
	      
        val.ms_error = val.ms_error.substring(0, val.ms_error.length - 2);

        val.mr_error = '';
        if (mr_err & 0x01)
          val.mr_error += 'Ballast failure, ';
        if (mr_err & 0x02)
          val.mr_error += 'Lamp failure, ';
        if (mr_err & 0x04)
          val.mr_error += 'Lamp on, ';
        else
          val.mr_error += 'Lamp off, ';
        if (mr_err & 0x08)
          val.mr_error += 'Power failure, ';
        if (mr_err & 0x10)
          val.mr_error += 'Emergency light failure, ';
        if (mr_err & 0x80)
          val.mr_error += 'Ballast missing, ';
        
        val.mr_error = val.mr_error.substring(0, val.mr_error.length - 2);
	      break;

	  case Cbuslib.errorsyscat['Modular Dimmer']:
	      //val.channel = data1;
	      val.ms_error = Cbuslib.error_modular_errs[ms_err];
        val.mr_error = Cbuslib.error_modular_errs[mr_err];
	      if (typeof val.ms_error === 'undefined')
          val.ms_error = 'Unknown';
        if (typeof val.mr_error === 'undefined')
          val.mr_error = 'Unknown';
	      break;
	}
	return val;

  case Cbuslib.appType.SECURITY:
    return Cbuslib.getSecurityData(id, hex, hexlen);

    default:
      if (!Cbuslib.appTypeIsLightingLike(app))
	return undefined;
      if (hexlen != 8)
	return undefined;

      // 4 bytes
      // 1: current value
      // 2: target value
      // 3-4: ramp rate (seconds for full scale ramp)
      return {
	value: parseInt(hex.substring(0, 2), 16),
	target: parseInt(hex.substring(2, 4), 16),
	ramprate: parseInt(hex.substring(4, 9), 16)
      }
  }

  Cbuslib.debug('failed to decode, app: ' + app + ', hexlen: ' + hexlen);
  return undefined;
}

// Generate printable data from the data returned by getData
Cbuslib.decodeData = function(id, data, skipparams)
{
  var app = id >>> 24;
  var val = Cbuslib.getData(id, data);
  var dec, full;

  if (typeof val == 'undefined') {
    return false;
  }

  switch (app) {
  case Cbuslib.appType.ENABLE:
    // 1 byte, 0-255
    if (isNaN(val.value)) {
      Cbuslib.debug('could not parse value for ENABLE');
      return false;
    }
    val.valuehtml = String(val.value);
    break;
  case Cbuslib.appType.EMERGENCY_LIGHT:
    if (isNaN(val.mode) || isNaN(val.progress)) {
      Cbuslib.debug('unable to parse for emergency exit lighting');
      return false;
    }
    val.valuehtml = String(val.mode +" "+val.progress);
    break;
  case Cbuslib.appType.TRIGGER:
    // 2 bytes, -1 or 0-255
    if (isNaN(val.value)) {
      Cbuslib.debug('could not parse value for TRIGGER');
      return false;
    }
    // Convert to signed
    if (val.value > 32767) {
      val.value = val.value - 65536;
    }
    if (val.value < -1 || val.value > 255) {
      Cbuslib.debug('value out of range for TRIGGER');
      return false;
    }
    val.valuehtml = String(val.value);
    break;

  case Cbuslib.appType.AUDIO: {
    var funcAddr = id & 0xFF;
    if (funcAddr >= Cbuslib.audioDatatypeMap.length) {
      Cbuslib.debug('index out of range for audioDatatypeMap');
      return false;
    }
    var dataType = Cbuslib.audioDatatypeMap[funcAddr];
    if (dataType == Cbuslib.MRADataType.MRA_DATA_TYPE_UINT8) {
      // 1 bytes value
      if (isNaN(val.value)) {
        Cbuslib.debug('could not parse value for AUDIO');
        return false;
      }
      var v = val.value & 0xFF;
      if (((funcAddr == Cbuslib.MRAFuncAddr.MRA_FUNC_ADDR_MUTE) && (v != 0) && (v != 2) && (v != 5) && (v != 7) && (v != 255))
        || ((funcAddr == Cbuslib.MRAFuncAddr.MRA_FUNC_ADDR_SRC_NUM) && ((v < 0) || (v > Cbuslib.CBUS_AUDIO_M_FEED_ID_MAX)))) {
        Cbuslib.debug('value out of range for AUDIO');
        return false;
      }
      val.valuehtml = String(v);
    } else if (dataType == Cbuslib.MRADataType.MRA_DATA_TYPE_VOLUME_ALIKE) {
      if (isNaN(val.value)) {
        val.value = val.target;
        full = true;
      }

      if (isNaN(val.target) || isNaN(val.ramprate)) {
        Cbuslib.debug('unable to parse for audio');
        return false;
      }

      if (val.value == val.target) {
        val.valuehtml = String(val.value);

        if (full) {
          val.valuehtml += '(' + val.ramprate + 's)';
        }
      } else {
        val.valuehtml = val.value + '->' + val.target + '(' + val.ramprate + 's)';
      }
    } else if (dataType == Cbuslib.MRADataType.MRA_DATA_TYPE_STRING) {
        if (((funcAddr == Cbuslib.MRAFuncAddr.MRA_FUNC_ADDR_MRA_COMMAND) && (String(val.value).length >= Cbuslib.MAX_MRA_MTC_COMMAND_OBJ_SIZE))
          || ((funcAddr != Cbuslib.MRAFuncAddr.MRA_FUNC_ADDR_MRA_COMMAND) && (String(val.value).length >= Cbuslib.MAX_MRA_MTC_STR_OBJ_SIZE))) {
          Cbuslib.debug('wrong string length for AUDIO');
          return false;
        }
        if (funcAddr == Cbuslib.MRAFuncAddr.MRA_FUNC_ADDR_MRA_COMMAND) {
          // check if cmd is a predefined cmd string and parameter num is correct
          var cmds = String(val.value).split(Cbuslib.MRA_MTC_CMD_PARAMETER_DELIMITER).filter(function(i) {
            return i
          });
          var pos = -1;
          for (var i = 0; i < Cbuslib.mraCommands.length; i++) {
            if (cmds[0] == Cbuslib.mraCommands[i]) {
              pos = i;
              break;
            }
          }
          if (pos == -1) {
            Cbuslib.debug('not a predefined string for AUDIO');
            return false;
          }
          if ((cmds.length - 1) != Cbuslib.mraCmdParameterLength[pos]) {
            Cbuslib.debug('cmd string with wrong parameters for AUDIO');
            return false;
          }
        }
        val.valuehtml = String(val.value);
        } else {
      Cbuslib.debug('wrong value type for AUDIO');
      return false;
    }
    break;
  }
  case Cbuslib.appType.MEDIA_TRANSPORT: {
    var funcAddr = id & 0xFF;
    if (funcAddr >= Cbuslib.mtcDatatypeMap.length) {
      Cbuslib.debug('index out of range for mtcDatatypeMap');
      return false;
    }
    var dataType = Cbuslib.mtcDatatypeMap[funcAddr];
    if ((dataType == Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT8) || (dataType == Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT16) || (dataType == Cbuslib.MTCDataType.MTC_DATA_TYPE_UINT32)) {
      if (isNaN(val.value)) {
        Cbuslib.debug('could not parse value for MTC');
        return false;
      }
      var v = val.value;

      if (((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_PLAY_STOP) && (v != 0) && (v != 1))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_PAUSE_RESUME) && (v != 0) && (v != 255))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_SHUFFLE) && (v != 0) && (v != 255))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_CATEGORY) && ((v < 0) || (v > 127)))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_TRACK) && ((v < 0) || (v > Cbuslib.MAX_MTC_TRACK_NUM)))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_TOTAL_TRACKS) && ((v < 0) || (v > Cbuslib.MAX_MTC_TRACK_NUM)))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_REPEAT) && ((v < 0) || (v > 255)))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_MTC_ENUM_SIZE_CAT) && ((v < 0) || (v > 255)))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_MTC_ENUM_SIZE_SEL) && ((v < 0) || (v > 255)))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_MTC_ENUM_SIZE_TRK) && ((v < 0) || (v > 255)))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_FORWARD) && (v != 0) && (v != 2) && (v != 4) && (v != 6)
            && (v != 8) && (v != 10) && (v != 12))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_REWIND) && (v != 0) && (v != 2) && (v != 4) && (v != 6)
            && (v != 8) && (v != 10) && (v != 12))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_SOURCE_POWER_CONTROL) && ((v < 0) || (v > 255)))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_SELECTION) && ((v < 0) || (v > Cbuslib.MAX_MTC_SEL_NUM)))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_TRACK) && ((v < 0) || (v > Cbuslib.MAX_MTC_TRACK_NUM)))
        || ((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_TOTAL_TRACKS) && ((v < 0) || (v > Cbuslib.MAX_MTC_TRACK_NUM)))) {
        Cbuslib.debug('v out of range for MTC');
        return false;
      }
      val.valuehtml = String(v);
    } else if (dataType == Cbuslib.MTCDataType.MTC_DATA_TYPE_STRING) {
        if (((funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_MTC_COMMAND) && (String(val.value).length >= Cbuslib.MAX_MRA_MTC_COMMAND_OBJ_SIZE))
          || ((funcAddr != Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_MTC_COMMAND) && (String(val.value).length >= Cbuslib.MAX_MRA_MTC_STR_OBJ_SIZE))) {
          Cbuslib.debug('wrong string length for MEDIA');
          return false;
        }
        if (funcAddr == Cbuslib.MTCFuncAddr.MTC_FUNC_ADDR_MTC_COMMAND) {
          // check if cmd is a predefined cmd string and parameter num is correct
          var cmds = String(val.value).split(Cbuslib.MRA_MTC_CMD_PARAMETER_DELIMITER).filter(function(i) {
            return i
          });
          var pos = -1;
          for (var i = 0; i < Cbuslib.mtcCommands.length; i++) {
            if (cmds[0] == Cbuslib.mtcCommands[i]) {
              pos = i;
              break;
            }
          }
          if (pos == -1) {
            Cbuslib.debug('not a predefined string for MEDIA');
            return false;
          }
          if ((cmds.length - 1) != Cbuslib.mtcCmdParameterLength[pos]) {
            Cbuslib.debug('cmd string with wrong parameters for MEDIA');
            return false;
          }
        }
        val.valuehtml = String(val.value);
        } else {
      Cbuslib.debug('wrong value type for MTC');
      return false;
    }
    break;
  }
  case Cbuslib.appType.NETWORK_CONTROL:
  case Cbuslib.appType.MEASUREMENT:
    // 5 bytes, 1-4: 32-bit MSB float, 5 units (CBUS-APP/28)
    val.unitshtml = Cbuslib.decodeMeasurementUnits(val.units);
    // Special case boolean measurement values
    if (val.units == 4 && app == Cbuslib.appType.MEASUREMENT)
    {
      if (val.value == 0)
      {
	val.value = false;
	val.valuehtml = "false";
      }
      else
      {
	val.value = true;
	val.valuehtml = "true";
      }
    }
    else
    {
      val.valuehtml = parseInt(val.value * 100) / 100 + ' ' + val.unitshtml; // Only print 2 decimal places
    }
    break;
  case Cbuslib.appType.ERROR:
    //var s_ms = val.sysidstr + '@' + '99' + '/';
    var s_ms = '';
    /*if (val.network != undefined) // Can't have network without channel
      s_ms += val.network;
    if (val.channel != undefined)
      s_ms += val.channel + '/';*/
    s_ms += Cbuslib.error_severity[val.ms_sev];
    if (typeof val.ms_error !== 'undefined')
      s_ms += '/' + val.ms_error;
    if (val.ms_ack)
      s_ms += ' (ack)'

    var s_mr = '';
    s_mr += Cbuslib.error_severity[val.mr_sev];
    if (typeof val.mr_error !== 'undefined')
      s_mr += '/' + val.mr_error;
    if (val.mr_ack)
      s_mr += ' (ack)'

    val.valuehtml = 'MS:'+s_ms+' | MR:'+s_mr;
    break;

  case Cbuslib.appType.SECURITY:
    val = Cbuslib.handleSecurityDecode(id, val);
    break;

  case Cbuslib.appType.USER_PARAM:
    Cbuslib.debug('user parameter');

    if (typeof data.decodedvalue !== 'undefined') {
      val = data.decodedvalue;
    }
    else {
      val = data.datadec;
    }

    dec = Scada.decodeValue(val, data.datatype, data.units, skipparams ? null : data.visparams, data.enums, true);
    val = { valuehtml: dec };
    break;

  default:
    if (!Cbuslib.appTypeIsLightingLike(app))
      return false;
    if (isNaN(val.value)) {
      val.value = val.target;
      full = true;
    }

    if (isNaN(val.target) || isNaN(val.ramprate)) {
      Cbuslib.debug('unable to parse for lighting');
      return false;
    }

    if (val.value == val.target) {
      val.valuehtml = String(val.value);
      if (full) {
        val.valuehtml += '(' + val.ramprate + 's)';
      }
    }
    else {
      val.valuehtml = val.value + '->' + val.target + '(' + val.ramprate + 's)';
    }
    break;
  }

  return val;
};

Cbuslib.decodeMeasurementUnits = function(units)
{
  switch (units) {
  case 0xfe:
    return "";
  case 0xff:
    return "custom";
  default:
    if (units > Cbuslib.measurementUnits.length)
      return "Unknown";
    else
      return Cbuslib.measurementUnits[units];
  }
}

/*!
 * Returns whether an application number uses the Lighting object Addressing:
 * - Lighting ($30 - $7F)
 * - Irrigation etc ($60 - $7F)
 * - Heating ($88)
 *
 * \param app The Application address.
 * \return true - if the application uses lighting-like group addressing
 *
 **************************************************************************/
Cbuslib.appTypeIsLightingLike =  function(app)
{
  return (((app >= 0x01) && (app <= 0x0F)) ||
          ((app >= Cbuslib.appType.LIGHTING_LOW) && (app <= Cbuslib.appType.LIGHTING_HIGH)) ||
          (app == Cbuslib.appType.HEATING) ||
          (app == Cbuslib.appType.TRIGGER) ||
          (app == Cbuslib.appType.ENABLE) );
}

/* Convert between percentage and level */
Cbuslib.CBusPctToLevel = function(pct) {
    return Math.floor(Math.floor(pct * 255.0) / 100.0);
}

Cbuslib.CBusLevelToPct = function(level) {
    return Math.floor(100.0 * (level + 0.9999999999999) / 255.0);
}

// Convert datahex into object for security application
Cbuslib.getSecurityData = function(id, hex, hexlen) {
  var objcode = (id >> 8) & 0xff;
  var zone = id & 0xff;
  var val = {};
  if (objcode >= Cbuslib.securityObjectCode.SEC_MAX)
    return undefined;
  if (zone > 0 && objcode < Cbuslib.securityObjectCode.SEC_ZONE_ISOLATED)
    return undefined;

  if (objcode >= Cbuslib.securityObjectCode.SEC_ZONE_ISOLATED)
    val.zone = zone;

  var objtype = Cbuslib.securityObjectType[objcode];

  switch (objtype) {
  case Scada.dt.access: // Command object
    if (hexlen < 2)
      return undefined;

    var cmd = parseInt(hex.substring(0, 2), 16);
    if (cmd >= Cbuslib.securityCommands.SECCMD_MAX)
      return undefined;

    val.command = Cbuslib.securityCommandNames[cmd];
    switch (cmd) {
    case Cbuslib.securityCommands.SECCMD_KEYPRESS:
      if (hexlen != 4)
	return undefined;
      val.key = parseInt(hex.substring(2, 4), 16);
      break;

    case Cbuslib.securityCommands.SECCMD_ARM:
      if (hexlen != 4)
	return undefined;
      val.level = parseInt(hex.substring(2, 4), 16);
      break;

    case Cbuslib.securityCommands.SECCMD_RAISE_ALARM:
    case Cbuslib.securityCommands.SECCMD_RAISE_TAMPER:
    case Cbuslib.securityCommands.SECCMD_DROP_TAMPER:
      if (hexlen != 2)
	return undefined;
      break;

    case Cbuslib.securityCommands.SECCMD_MESSAGE:
      if (hexlen > Cbuslib.SEC_MAX_MESSAGE_LEN * 2 + 2)
	return undefined;
      val.message = Cbuslib.hex2bin(hex.substring(2));
      break;

    default:
      return undefined;
      break;
    }
    break;

  case Scada.dt.bool:
  case Scada.dt.uint8:
    if (hexlen != 2)
      return undefined;
    val.value = parseInt(hex, 16);
    if (objtype == Scada.dt.bool)
      val.value = Boolean(val.value);
    break;

  case Scada.dt.string:
    val.message = Cbuslib.hex2bin(hex);
    break;
  }

  return val;
}

// Convert data object into human readable object for security application
Cbuslib.handleSecurityDecode = function(id, val) {
  if (val.command != undefined) {
    // Command object
    val.valuehtml = val.command
    if (val.key != undefined) {
      if (isNaN(val.key))
	return false;
      if (Cbuslib.securitySpecialKeys[val.key] != undefined)
	val.valuehtml += ': &lt;' + Cbuslib.securitySpecialKeys[val.key] + '&gt;';
      else if (val.key > 0x20 && val.key < 0x7f)
	val.valuehtml += ': ' + String.fromCharCode(val.key);
      else
	val.valuehtml += ': 0x' + val.key.toString(16);
    } else if (val.level != undefined) {
      if (Cbuslib.securityArmLevels[val.level] != undefined)
	val.valuehtml += ': ' + Cbuslib.securityArmLevels[val.level];
      else
	val.valuehtml += ': 0x' + val.level.toString(16);
    } else if (val.message != undefined) {
      val.valuehtml += ': ' + val.message;
    }
  } else if (val.value != undefined) {
    // bool / uint8 objects
    val.valuehtml = val.value.toString();
  } else if (val.message != undefined) {
    // message object
    val.valuehtml = val.message;
  }
  return val;
}

// Scada is only defined on the real device, make sure tests don't blow up
if (typeof Scada != 'undefined') {
  Scada.decodeIndAddress = Cbuslib.decodeUnitAddress;
  Scada.encodeIndAddress = Cbuslib.encodeUnitAddress;
  Scada.decodeGroupAddress= Cbuslib.decodeObjectAddress;
  Scada.encodeGroupAddress = Cbuslib.encodeObjectAddress;
}
/* EOF */
