function toggleIcons(){var EMERGENCY_EXIT_LIGHT=true;var element=document.getElementById("emergency-light-icon");if(EMERGENCY_EXIT_LIGHT)element.className=""}
